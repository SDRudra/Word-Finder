package com.example.data.model

enum class WordSource {
    LOCAL_CACHE,
    GEMINI_AI,
    MANUAL
}

data class DuplicateConflict(
    val conflictingWord: String,
    val sourceField: String, // "Main Word", "Synonym", "Antonym"
    val targetRowIndex: Int,
    val targetField: String, // "Main Word", "Synonym", "Antonym"
    val targetMainWord: String
) {
    fun toUserMessage(): String {
        return "'$conflictingWord' ($sourceField) duplicates $targetField on Row $targetRowIndex ('$targetMainWord')"
    }
}

data class WebSemanticMatch(
    val newWord: String,
    val matchedRowIndex: Int,
    val matchedMainWord: String,
    val relationship: String, // "synonym" or "antonym"
    val explanation: String
)

data class WordAdditionAnalysisResult(
    val isDirectDuplicate: Boolean = false,
    val directConflict: DuplicateConflict? = null,
    val webSemanticMatch: WebSemanticMatch? = null,
    val synonyms: List<String> = emptyList(),
    val antonyms: List<String> = emptyList()
)

data class WordLookupResult(
    val word: String,
    val synonyms: List<String>,
    val antonyms: List<String>,
    val source: WordSource
)
