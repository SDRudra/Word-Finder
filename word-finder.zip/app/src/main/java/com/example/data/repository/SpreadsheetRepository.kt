package com.example.data.repository

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.gemini.GeminiService
import com.example.data.local.DictionaryDao
import com.example.data.local.DictionaryEntryEntity
import com.example.data.local.OfflineWordDatabase
import com.example.data.local.RowDao
import com.example.data.local.RowEntity
import com.example.data.local.SheetDao
import com.example.data.local.SheetEntity
import com.example.data.model.DuplicateConflict
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class SpreadsheetRepository(
    private val sheetDao: SheetDao,
    private val rowDao: RowDao,
    private val dictionaryDao: DictionaryDao,
    private val geminiService: GeminiService,
    private val appScope: CoroutineScope
) {
    fun getAllSheets(): Flow<List<SheetEntity>> = sheetDao.getAllSheets()

    fun getRowsForSheet(sheetId: Long): Flow<List<RowEntity>> = rowDao.getRowsForSheet(sheetId)

    suspend fun createSheet(title: String): Long = withContext(Dispatchers.IO) {
        val sheet = SheetEntity(
            title = if (title.isBlank()) "Untitled Sheet" else title.trim()
        )
        val id = sheetDao.insertSheet(sheet)
        // Add sample starter row
        rowDao.insertRow(
            RowEntity(
                sheetId = id,
                position = 1,
                mainWord = "bright",
                synonyms = "radiant, luminous, brilliant, shining",
                antonyms = "dark, dim, dull, gloomy",
                source = "LOCAL_CACHE"
            )
        )
        id
    }

    suspend fun updateSheetTitle(sheetId: Long, newTitle: String) = withContext(Dispatchers.IO) {
        val sheet = sheetDao.getSheetById(sheetId) ?: return@withContext
        sheetDao.updateSheet(sheet.copy(title = newTitle.trim(), updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteSheet(sheetId: Long) = withContext(Dispatchers.IO) {
        sheetDao.deleteSheetById(sheetId)
    }

    suspend fun addRowWithWord(
        sheetId: Long,
        word: String,
        onWebMatchFound: ((com.example.data.model.WebSemanticMatch) -> Unit)? = null
    ): Long = withContext(Dispatchers.IO) {
        val trimmedWord = word.trim()
        val currentCount = rowDao.getRowCountForSheet(sheetId)
        val newPosition = currentCount + 1

        // Check local cache for immediate display if available
        val localCached = findWordLocally(trimmedWord)

        val rowId = rowDao.insertRow(
            RowEntity(
                sheetId = sheetId,
                position = newPosition,
                mainWord = trimmedWord,
                synonyms = localCached?.synonyms ?: "",
                antonyms = localCached?.antonyms ?: "",
                source = if (localCached != null) "LOCAL_CACHE" else "GEMINI_AI",
                isLoadingAi = true,
                statusMessage = "Analyzing with Gemini AI & checking web relationships..."
            )
        )

        // Asynchronously call Gemini AI client to search web & analyze relationships
        appScope.launch(Dispatchers.IO) {
            val previousRows = rowDao.getRowsForSheetOnce(sheetId).filter { it.id != rowId }
            lookupWithGeminiAndUpdateRow(
                rowId = rowId,
                word = trimmedWord,
                previousRows = previousRows,
                hasLocalFallback = localCached != null,
                onWebMatchFound = onWebMatchFound
            )
        }

        rowId
    }

    suspend fun retryGeminiLookup(
        rowId: Long,
        onWebMatchFound: ((com.example.data.model.WebSemanticMatch) -> Unit)? = null
    ) = withContext(Dispatchers.IO) {
        val row = rowDao.getRowById(rowId) ?: return@withContext
        rowDao.updateRow(row.copy(isLoadingAi = true, statusMessage = "Analyzing with Gemini AI & checking web relationships..."))
        appScope.launch(Dispatchers.IO) {
            val previousRows = rowDao.getRowsForSheetOnce(row.sheetId).filter { it.id != rowId }
            lookupWithGeminiAndUpdateRow(
                rowId = rowId,
                word = row.mainWord,
                previousRows = previousRows,
                hasLocalFallback = row.synonyms.isNotBlank(),
                onWebMatchFound = onWebMatchFound
            )
        }
    }

    private suspend fun lookupWithGeminiAndUpdateRow(
        rowId: Long,
        word: String,
        previousRows: List<RowEntity>,
        hasLocalFallback: Boolean = false,
        onWebMatchFound: ((com.example.data.model.WebSemanticMatch) -> Unit)? = null
    ) {
        val existingWordsOverview = previousRows.map { row ->
            val listed = listOf(row.synonyms, row.antonyms)
                .filter { it.isNotBlank() }
                .joinToString("; ")
            Triple(row.position, row.mainWord, listed.ifBlank { "none listed" })
        }

        val result = geminiService.analyzeWordAdditionWithWebSearch(word, existingWordsOverview)
        val currentRow = rowDao.getRowById(rowId) ?: return

        result.onSuccess { (lookupResult, webMatch) ->
            val synString = lookupResult.synonyms.joinToString(", ")
            val antString = lookupResult.antonyms.joinToString(", ")

            rowDao.updateRow(
                currentRow.copy(
                    synonyms = synString,
                    antonyms = antString,
                    source = "GEMINI_AI",
                    isLoadingAi = false,
                    statusMessage = null,
                    updatedAt = System.currentTimeMillis()
                )
            )

            // Cache in local database for subsequent fast lookups
            dictionaryDao.insertWord(
                DictionaryEntryEntity(
                    word = word.lowercase(),
                    synonyms = synString,
                    antonyms = antString,
                    isAiGenerated = true
                )
            )

            // If an unlisted web match was discovered, trigger notification callback
            if (webMatch != null) {
                onWebMatchFound?.invoke(webMatch)
            }
        }.onFailure { error ->
            // Fallback to basic fetch if advanced prompt had issue
            val basicResult = geminiService.fetchSynonymsAndAntonyms(word)
            basicResult.onSuccess { lookupResult ->
                val synString = lookupResult.synonyms.joinToString(", ")
                val antString = lookupResult.antonyms.joinToString(", ")

                rowDao.updateRow(
                    currentRow.copy(
                        synonyms = synString,
                        antonyms = antString,
                        source = "GEMINI_AI",
                        isLoadingAi = false,
                        statusMessage = null,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }.onFailure { basicError ->
                val errorMsg = basicError.message ?: "Failed to find word on Gemini"
                rowDao.updateRow(
                    currentRow.copy(
                        isLoadingAi = false,
                        statusMessage = if (hasLocalFallback) null else errorMsg,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    suspend fun updateRowCells(
        rowId: Long,
        mainWord: String,
        synonyms: String,
        antonyms: String,
        retriggerAiIfChanged: Boolean = false
    ) = withContext(Dispatchers.IO) {
        val row = rowDao.getRowById(rowId) ?: return@withContext
        val oldWord = row.mainWord.trim()
        val newWord = mainWord.trim()

        if (retriggerAiIfChanged && oldWord.lowercase() != newWord.lowercase() && newWord.isNotEmpty()) {
            val localCached = findWordLocally(newWord)
            rowDao.updateRow(
                row.copy(
                    mainWord = newWord,
                    synonyms = localCached?.synonyms ?: "",
                    antonyms = localCached?.antonyms ?: "",
                    source = if (localCached != null) "LOCAL_CACHE" else "GEMINI_AI",
                    isLoadingAi = true,
                    statusMessage = "Fetching synonyms & antonyms with Gemini AI...",
                    updatedAt = System.currentTimeMillis()
                )
            )
            appScope.launch(Dispatchers.IO) {
                val previousRows = rowDao.getRowsForSheetOnce(row.sheetId).filter { it.id != rowId }
                lookupWithGeminiAndUpdateRow(
                    rowId = rowId,
                    word = newWord,
                    previousRows = previousRows,
                    hasLocalFallback = localCached != null
                )
            }
        } else {
            rowDao.updateRow(
                row.copy(
                    mainWord = newWord,
                    synonyms = synonyms.trim(),
                    antonyms = antonyms.trim(),
                    source = "MANUAL",
                    isLoadingAi = false,
                    statusMessage = null,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun deleteRow(rowId: Long) = withContext(Dispatchers.IO) {
        rowDao.deleteRowById(rowId)
    }

    suspend fun clearSheetRows(sheetId: Long) = withContext(Dispatchers.IO) {
        rowDao.clearSheetRows(sheetId)
    }

    suspend fun findWordLocally(word: String): DictionaryEntryEntity? = withContext(Dispatchers.IO) {
        val normalized = word.trim().lowercase()
        // Check Room cached dictionary
        val cached = dictionaryDao.findWord(normalized)
        if (cached != null) return@withContext cached

        // Check in-memory initial dictionary
        val fallback = OfflineWordDatabase.initialDictionary[normalized]
        if (fallback != null) {
            val entity = DictionaryEntryEntity(
                word = normalized,
                synonyms = fallback.first.joinToString(", "),
                antonyms = fallback.second.joinToString(", "),
                isAiGenerated = false
            )
            dictionaryDao.insertWord(entity)
            return@withContext entity
        }
        null
    }

    // Duplicate detection helper
    fun detectDuplicates(rows: List<RowEntity>): Map<Long, List<DuplicateConflict>> {
        val duplicateMap = mutableMapOf<Long, MutableList<DuplicateConflict>>()

        for (i in rows.indices) {
            val rowA = rows[i]
            val wordsA = extractRowWords(rowA)

            for (j in rows.indices) {
                if (i == j) continue
                val rowB = rows[j]
                val wordsB = extractRowWords(rowB)

                for ((termA, fieldA) in wordsA) {
                    for ((termB, fieldB) in wordsB) {
                        if (termA.isNotBlank() && termA.equals(termB, ignoreCase = true)) {
                            val conflict = DuplicateConflict(
                                conflictingWord = termA,
                                sourceField = fieldA,
                                targetRowIndex = rowB.position,
                                targetField = fieldB,
                                targetMainWord = rowB.mainWord.ifBlank { "(empty)" }
                            )
                            val list = duplicateMap.getOrPut(rowA.id) { mutableListOf() }
                            if (list.none { it.conflictingWord.equals(termA, ignoreCase = true) && it.targetRowIndex == rowB.position && it.targetField == fieldB }) {
                                list.add(conflict)
                            }
                        }
                    }
                }
            }
        }
        return duplicateMap
    }

    private fun extractRowWords(row: RowEntity): List<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        if (row.mainWord.isNotBlank()) {
            list.add(Pair(row.mainWord.trim().lowercase(), "Main Word"))
        }
        val syns = row.synonyms.split(",", ";").map { it.trim().lowercase() }.filter { it.isNotBlank() }
        syns.forEach { list.add(Pair(it, "Synonym")) }

        val ants = row.antonyms.split(",", ";").map { it.trim().lowercase() }.filter { it.isNotBlank() }
        ants.forEach { list.add(Pair(it, "Antonym")) }
        return list
    }

    // CSV generation
    fun generateCsv(rows: List<RowEntity>): String {
        val sb = StringBuilder()
        sb.append("\"Row\",\"Main Word\",\"Synonyms\",\"Antonyms\",\"Source\"\n")
        rows.forEachIndexed { index, row ->
            val rowNum = index + 1
            sb.append("\"").append(rowNum).append("\",")
            sb.append(escapeCsv(row.mainWord)).append(",")
            sb.append(escapeCsv(row.synonyms)).append(",")
            sb.append(escapeCsv(row.antonyms)).append(",")
            sb.append(escapeCsv(row.source))
            sb.append("\n")
        }
        return sb.toString()
    }

    private fun escapeCsv(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    suspend fun createCsvFile(context: Context, sheetTitle: String, rows: List<RowEntity>): Uri = withContext(Dispatchers.IO) {
        val cleanTitle = sheetTitle.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "Spreadsheet" }
        val fileName = "${cleanTitle}_${System.currentTimeMillis()}.csv"
        val cacheFile = File(context.cacheDir, fileName)

        val csvData = generateCsv(rows)
        FileOutputStream(cacheFile).use { fos ->
            fos.write(csvData.toByteArray(Charsets.UTF_8))
        }

        FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            cacheFile
        )
    }
}
