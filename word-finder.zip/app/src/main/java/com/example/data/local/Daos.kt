package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SheetDao {
    @Query("SELECT * FROM sheets ORDER BY createdAt ASC")
    fun getAllSheets(): Flow<List<SheetEntity>>

    @Query("SELECT * FROM sheets WHERE id = :id LIMIT 1")
    suspend fun getSheetById(id: Long): SheetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSheet(sheet: SheetEntity): Long

    @Update
    suspend fun updateSheet(sheet: SheetEntity)

    @Delete
    suspend fun deleteSheet(sheet: SheetEntity)

    @Query("DELETE FROM sheets WHERE id = :id")
    suspend fun deleteSheetById(id: Long)
}

@Dao
interface RowDao {
    @Query("SELECT * FROM spreadsheet_rows WHERE sheetId = :sheetId ORDER BY position ASC, id ASC")
    fun getRowsForSheet(sheetId: Long): Flow<List<RowEntity>>

    @Query("SELECT * FROM spreadsheet_rows WHERE sheetId = :sheetId ORDER BY position ASC, id ASC")
    suspend fun getRowsForSheetOnce(sheetId: Long): List<RowEntity>

    @Query("SELECT * FROM spreadsheet_rows WHERE id = :id LIMIT 1")
    suspend fun getRowById(id: Long): RowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRow(row: RowEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRows(rows: List<RowEntity>)

    @Update
    suspend fun updateRow(row: RowEntity)

    @Delete
    suspend fun deleteRow(row: RowEntity)

    @Query("DELETE FROM spreadsheet_rows WHERE id = :id")
    suspend fun deleteRowById(id: Long)

    @Query("DELETE FROM spreadsheet_rows WHERE sheetId = :sheetId")
    suspend fun clearSheetRows(sheetId: Long)

    @Query("SELECT COUNT(*) FROM spreadsheet_rows WHERE sheetId = :sheetId")
    suspend fun getRowCountForSheet(sheetId: Long): Int
}

@Dao
interface DictionaryDao {
    @Query("SELECT * FROM cached_dictionary WHERE LOWER(word) = LOWER(:word) LIMIT 1")
    suspend fun findWord(word: String): DictionaryEntryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWord(entry: DictionaryEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(entries: List<DictionaryEntryEntity>)
}
