package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [SheetEntity::class, RowEntity::class, DictionaryEntryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sheetDao(): SheetDao
    abstract fun rowDao(): RowDao
    abstract fun dictionaryDao(): DictionaryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "synonym_antonym_finder.db"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: AppDatabase) {
                val sheetDao = database.sheetDao()
                val rowDao = database.rowDao()
                val dictDao = database.dictionaryDao()

                // Seed offline dictionary cache
                val dictEntries = OfflineWordDatabase.initialDictionary.map { (word, pair) ->
                    DictionaryEntryEntity(
                        word = word,
                        synonyms = pair.first.joinToString(", "),
                        antonyms = pair.second.joinToString(", "),
                        isAiGenerated = false
                    )
                }
                dictDao.insertWords(dictEntries)

                // Create initial default spreadsheet
                val sheetId = sheetDao.insertSheet(
                    SheetEntity(
                        title = "Vocabulary Sheet 1"
                    )
                )

                // Seed starter rows to showcase auto-population immediately
                val starterWords = listOf("happy", "brave", "calm", "create")
                starterWords.forEachIndexed { index, word ->
                    val entry = OfflineWordDatabase.initialDictionary[word]
                    val synonyms = entry?.first?.joinToString(", ") ?: ""
                    val antonyms = entry?.second?.joinToString(", ") ?: ""
                    rowDao.insertRow(
                        RowEntity(
                            sheetId = sheetId,
                            position = index + 1,
                            mainWord = word,
                            synonyms = synonyms,
                            antonyms = antonyms,
                            source = "LOCAL_CACHE",
                            isLoadingAi = false
                        )
                    )
                }
            }
        }
    }
}
