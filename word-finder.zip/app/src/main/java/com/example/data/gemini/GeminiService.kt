package com.example.data.gemini

import android.util.Log
import com.example.data.model.WordLookupResult
import com.example.data.model.WordSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService(
    private val apiKeyProvider: () -> String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchSynonymsAndAntonyms(word: String): Result<WordLookupResult> = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is missing. Set it in Secrets or tap 'Gemini Settings' in the app menu.")
            )
        }

        try {
            // Using gemini-3.5-flash as specified for Basic Text Tasks
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val prompt = """
                Provide common synonyms and antonyms for the English word: "$word".
                Return strictly a JSON object with two array fields:
                "synonyms": an array of 3 to 6 strings representing synonyms,
                "antonyms": an array of 3 to 6 strings representing antonyms.
                Ensure synonyms and antonyms are accurate and contextually relevant.
            """.trimIndent()

            val requestBodyJson = JSONObject().apply {
                val partsArray = JSONArray().apply {
                    put(JSONObject().apply { put("text", prompt) })
                }
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply { put("parts", partsArray) })
                }
                put("contents", contentsArray)

                val generationConfig = JSONObject().apply {
                    put("temperature", 0.2)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", generationConfig)
            }

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e("GeminiService", "Gemini API error: ${response.code} $responseBody")
                val friendlyMessage = when (response.code) {
                    400 -> "Invalid API request (HTTP 400). Please verify API key."
                    403 -> "Invalid or unauthorized Gemini API key (HTTP 403)."
                    429 -> "Gemini API quota exceeded (HTTP 429). Please try again shortly."
                    else -> "Gemini API error (${response.code}): ${response.message}"
                }
                return@withContext Result.failure(RuntimeException(friendlyMessage))
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text", "") ?: ""

            if (rawText.isBlank()) {
                return@withContext Result.failure(RuntimeException("Empty response returned by Gemini."))
            }

            // Clean code fences or extra whitespace if any
            var cleanedText = rawText.trim()
            if (cleanedText.startsWith("```")) {
                cleanedText = cleanedText.substringAfter("\n")
            }
            if (cleanedText.endsWith("```")) {
                cleanedText = cleanedText.substringBeforeLast("```")
            }
            cleanedText = cleanedText.trim()

            val wordJson = JSONObject(cleanedText)

            val synonyms = mutableListOf<String>()
            val synonymsJson = wordJson.optJSONArray("synonyms")
            if (synonymsJson != null) {
                for (i in 0 until synonymsJson.length()) {
                    val item = synonymsJson.optString(i).trim()
                    if (item.isNotBlank()) synonyms.add(item)
                }
            } else {
                val synStr = wordJson.optString("synonyms", "")
                if (synStr.isNotBlank()) {
                    synonyms.addAll(synStr.split(",").map { it.trim() }.filter { it.isNotBlank() })
                }
            }

            val antonyms = mutableListOf<String>()
            val antonymsJson = wordJson.optJSONArray("antonyms")
            if (antonymsJson != null) {
                for (i in 0 until antonymsJson.length()) {
                    val item = antonymsJson.optString(i).trim()
                    if (item.isNotBlank()) antonyms.add(item)
                }
            } else {
                val antStr = wordJson.optString("antonyms", "")
                if (antStr.isNotBlank()) {
                    antonyms.addAll(antStr.split(",").map { it.trim() }.filter { it.isNotBlank() })
                }
            }

            Result.success(
                WordLookupResult(
                    word = word,
                    synonyms = synonyms,
                    antonyms = antonyms,
                    source = WordSource.GEMINI_AI
                )
            )
        } catch (e: Exception) {
            Log.e("GeminiService", "Exception in GeminiService: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Searches web/dictionary knowledge to check if [newWord] matches any broader, unlisted
     * synonyms or antonyms of previously existing words on the spreadsheet, while simultaneously
     * fetching synonyms & antonyms for [newWord].
     */
    suspend fun analyzeWordAdditionWithWebSearch(
        newWord: String,
        existingWordsOverview: List<Triple<Int, String, String>> // (rowIndex, mainWord, listedWordsOverview)
    ): Result<Pair<WordLookupResult, com.example.data.model.WebSemanticMatch?>> = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is missing. Set it in Secrets or tap 'Gemini Settings' in the app menu.")
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val existingWordsPrompt = if (existingWordsOverview.isEmpty()) {
                "The spreadsheet currently has no other rows."
            } else {
                buildString {
                    append("Here are the existing words on the spreadsheet:\n")
                    for ((rowIndex, mainWord, overview) in existingWordsOverview) {
                        append("- Row $rowIndex: Main Word = \"$mainWord\" (Currently listed related: $overview)\n")
                    }
                }
            }

            val prompt = """
                You are an expert lexicographer and vocabulary assistant.
                The user is adding the word: "$newWord" to a vocabulary spreadsheet.

                $existingWordsPrompt

                Perform two tasks:
                1. Provide 3 to 6 common synonyms and 3 to 6 antonyms for the new word "$newWord".
                2. Examine ALL existing rows above. Search your comprehensive web and dictionary knowledge:
                   Check if "$newWord" is a valid synonym or antonym for any of the previous main words,
                   EVEN IF that relationship is NOT explicitly written or listed in the spreadsheet's current columns.
                   For example, if Row 1 has "candid", and the user adds "frank" or "dishonest", recognize this semantic match from web dictionary knowledge.
                   If there is an unlisted web synonym or antonym match with one of the previous rows, set "hasWebMatch" to true and describe it.
                   If it does not match any previous word's broader synonyms/antonyms, set "hasWebMatch" to false.

                Respond strictly with a JSON object in this exact schema:
                {
                  "synonyms": ["synonym1", "synonym2", ...],
                  "antonyms": ["antonym1", "antonym2", ...],
                  "webMatch": {
                    "hasMatch": true or false,
                    "matchedRowIndex": 1,
                    "matchedMainWord": "candid",
                    "relationship": "synonym" or "antonym",
                    "explanation": "Brief explanation of how '$newWord' is an unlisted synonym/antonym for the word on row 1"
                  }
                }
            """.trimIndent()

            val requestBodyJson = JSONObject().apply {
                val partsArray = JSONArray().apply {
                    put(JSONObject().apply { put("text", prompt) })
                }
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply { put("parts", partsArray) })
                }
                put("contents", contentsArray)

                val generationConfig = JSONObject().apply {
                    put("temperature", 0.2)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", generationConfig)
            }

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e("GeminiService", "Gemini API error during web search analysis: ${response.code} $responseBody")
                return@withContext Result.failure(RuntimeException("Gemini API error (${response.code})"))
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text", "") ?: ""

            if (rawText.isBlank()) {
                return@withContext Result.failure(RuntimeException("Empty response returned by Gemini."))
            }

            var cleanedText = rawText.trim()
            if (cleanedText.startsWith("```")) {
                cleanedText = cleanedText.substringAfter("\n")
            }
            if (cleanedText.endsWith("```")) {
                cleanedText = cleanedText.substringBeforeLast("```")
            }
            cleanedText = cleanedText.trim()

            val wordJson = JSONObject(cleanedText)

            val synonyms = mutableListOf<String>()
            val synonymsJson = wordJson.optJSONArray("synonyms")
            if (synonymsJson != null) {
                for (i in 0 until synonymsJson.length()) {
                    val item = synonymsJson.optString(i).trim()
                    if (item.isNotBlank()) synonyms.add(item)
                }
            }

            val antonyms = mutableListOf<String>()
            val antonymsJson = wordJson.optJSONArray("antonyms")
            if (antonymsJson != null) {
                for (i in 0 until antonymsJson.length()) {
                    val item = antonymsJson.optString(i).trim()
                    if (item.isNotBlank()) antonyms.add(item)
                }
            }

            var webSemanticMatch: com.example.data.model.WebSemanticMatch? = null
            val matchObj = wordJson.optJSONObject("webMatch")
            if (matchObj != null && matchObj.optBoolean("hasMatch", false)) {
                val matchedRowIndex = matchObj.optInt("matchedRowIndex", 0)
                val matchedMainWord = matchObj.optString("matchedMainWord", "").trim()
                val relationship = matchObj.optString("relationship", "synonym").trim().lowercase()
                val explanation = matchObj.optString("explanation", "").trim()

                if (matchedMainWord.isNotBlank()) {
                    webSemanticMatch = com.example.data.model.WebSemanticMatch(
                        newWord = newWord,
                        matchedRowIndex = matchedRowIndex,
                        matchedMainWord = matchedMainWord,
                        relationship = relationship,
                        explanation = explanation.ifBlank {
                            "'$newWord' is an unlisted $relationship for '$matchedMainWord' on Row $matchedRowIndex"
                        }
                    )
                }
            }

            val lookupResult = WordLookupResult(
                word = newWord,
                synonyms = synonyms,
                antonyms = antonyms,
                source = WordSource.GEMINI_AI
            )

            Result.success(Pair(lookupResult, webSemanticMatch))
        } catch (e: Exception) {
            Log.e("GeminiService", "Exception in analyzeWordAdditionWithWebSearch: ${e.message}", e)
            Result.failure(e)
        }
    }
}
