package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "sheets")
data class SheetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "spreadsheet_rows",
    foreignKeys = [
        ForeignKey(
            entity = SheetEntity::class,
            parentColumns = ["id"],
            childColumns = ["sheetId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["sheetId"])]
)
data class RowEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sheetId: Long,
    val position: Int,
    val mainWord: String,
    val synonyms: String = "",
    val antonyms: String = "",
    val source: String = "LOCAL_CACHE",
    val isLoadingAi: Boolean = false,
    val statusMessage: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_dictionary")
data class DictionaryEntryEntity(
    @PrimaryKey
    val word: String,
    val synonyms: String,
    val antonyms: String,
    val isAiGenerated: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
