package com.example.data.gemini

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class ApiKeyManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("gemini_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_USER_API_KEY = "user_gemini_api_key"
    }

    fun getActiveApiKey(): String {
        // 1. Check user-configured key in SharedPreferences
        val savedKey = prefs.getString(KEY_USER_API_KEY, "")?.trim() ?: ""
        if (savedKey.isNotBlank()) {
            return savedKey
        }

        // 2. Fall back to BuildConfig.GEMINI_API_KEY
        val buildKey = BuildConfig.GEMINI_API_KEY.trim()
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey
        }

        return ""
    }

    fun getSavedUserKey(): String {
        return prefs.getString(KEY_USER_API_KEY, "") ?: ""
    }

    fun saveUserApiKey(key: String) {
        prefs.edit().putString(KEY_USER_API_KEY, key.trim()).apply()
    }

    fun hasValidKey(): Boolean {
        return getActiveApiKey().isNotBlank()
    }

    fun getKeySourceDescription(): String {
        val saved = prefs.getString(KEY_USER_API_KEY, "")?.trim() ?: ""
        if (saved.isNotBlank()) return "Configured in App Settings"
        val buildKey = BuildConfig.GEMINI_API_KEY.trim()
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") return "Configured via BuildConfig / .env"
        return "Not configured"
    }
}
