package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.RowEntity
import com.example.data.model.DuplicateConflict
import com.example.ui.theme.AntonymRose
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandPrimaryContainer
import com.example.ui.theme.BrandPrimaryDark
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.SynonymGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.ui.theme.WarningAmberBorder
import com.example.ui.theme.WebMatchIndigo
import com.example.ui.theme.WebMatchIndigoBg
import com.example.ui.theme.WebMatchIndigoBorder
import com.example.ui.theme.WebMatchIndigoDark
import com.example.data.model.WebSemanticMatch

@Composable
fun AddSheetDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var title by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.TableChart, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("New Spreadsheet Tab", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Slate900)
            }
        },
        text = {
            Column {
                Text(
                    text = "Organize vocabulary sets, GRE lists, or topic-specific synonyms and antonyms:",
                    fontSize = 13.sp,
                    color = Slate600
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal
                    ),
                    placeholder = { Text("e.g. Advanced English, GRE High Frequency", fontSize = 13.sp, color = Slate400) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = BrandPrimary,
                        focusedBorderColor = BrandPrimary,
                        unfocusedBorderColor = Slate300,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sheet_name_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) onConfirm(title.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("confirm_create_sheet_button")
            ) {
                Text("Create Tab", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Slate600)
            }
        }
    )
}

@Composable
fun RenameSheetDialog(
    currentTitle: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var title by remember { mutableStateOf(currentTitle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = { Text("Rename Spreadsheet Tab", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Slate900) },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal
                    ),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = BrandPrimary,
                        focusedBorderColor = BrandPrimary,
                        unfocusedBorderColor = Slate300,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rename_sheet_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) onConfirm(title.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Save", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Slate600)
            }
        }
    )
}

@Composable
fun EditRowDialog(
    row: RowEntity,
    conflicts: List<DuplicateConflict>?,
    onDismiss: () -> Unit,
    onSave: (mainWord: String, synonyms: String, antonyms: String) -> Unit,
    onRetryAi: () -> Unit
) {
    var mainWord by remember { mutableStateOf(row.mainWord) }
    var synonyms by remember { mutableStateOf(row.synonyms) }
    var antonyms by remember { mutableStateOf(row.antonyms) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = BrandPrimaryContainer,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = "#${row.position}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandPrimaryDark,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text("Edit Row", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Slate900)
                }
                if (row.isLoadingAi) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = BrandPrimary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (!conflicts.isNullOrEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarningAmberBg),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmberBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.WarningAmber,
                                    contentDescription = "Warning",
                                    tint = WarningAmber,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Cross-Column Duplicate Warning",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF78350F),
                                    fontSize = 12.5.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            conflicts.forEach { conflict ->
                                Text(
                                    text = "• '${conflict.conflictingWord}' already exists on Row ${conflict.targetRowIndex} as ${conflict.targetField}",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF92400E)
                                )
                            }
                        }
                    }
                }

                if (row.statusMessage != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Slate100),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(10.dp)
                        ) {
                            Text(
                                text = row.statusMessage,
                                fontSize = 12.sp,
                                color = Slate700,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = onRetryAi,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp), tint = BrandPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Retry AI", fontSize = 11.sp, color = BrandPrimary)
                            }
                        }
                    }
                }

                Text("Main Word", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = Slate800)
                OutlinedTextField(
                    value = mainWord,
                    onValueChange = { mainWord = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    placeholder = { Text("e.g. courageous", fontSize = 13.sp, color = Slate400) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = BrandPrimary,
                        focusedBorderColor = BrandPrimary,
                        unfocusedBorderColor = Slate300,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                        .testTag("edit_main_word_input")
                )

                Text("Synonyms (comma-separated)", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = SynonymGreen)
                OutlinedTextField(
                    value = synonyms,
                    onValueChange = { synonyms = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal
                    ),
                    placeholder = { Text("e.g. brave, bold, fearless", fontSize = 13.sp, color = Slate400) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = SynonymGreen,
                        focusedBorderColor = SynonymGreen,
                        unfocusedBorderColor = Slate300,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                        .testTag("edit_synonyms_input")
                )

                Text("Antonyms (comma-separated)", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = AntonymRose)
                OutlinedTextField(
                    value = antonyms,
                    onValueChange = { antonyms = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal
                    ),
                    placeholder = { Text("e.g. cowardly, fearful, timid", fontSize = 13.sp, color = Slate400) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = AntonymRose,
                        focusedBorderColor = AntonymRose,
                        unfocusedBorderColor = Slate300,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 8.dp)
                        .testTag("edit_antonyms_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(mainWord, synonyms, antonyms)
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("save_row_button")
            ) {
                Text("Save Changes", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Slate600)
            }
        }
    )
}

@Composable
fun DuplicateDetailsDialog(
    row: RowEntity,
    conflicts: List<DuplicateConflict>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.WarningAmber,
                    contentDescription = "Warning",
                    tint = WarningAmber,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Duplicate Conflict Details", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Slate900)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Row #${row.position} ('${row.mainWord}') has words overlapping with other rows in this spreadsheet:",
                    fontSize = 13.sp,
                    color = Slate700
                )
                Spacer(modifier = Modifier.height(12.dp))

                conflicts.forEach { conflict ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarningAmberBg),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmberBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Conflicting Word: \"${conflict.conflictingWord}\"",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF78350F),
                                fontSize = 13.5.sp
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Located in this row's ${conflict.sourceField}.",
                                color = Color(0xFF92400E),
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Already logged in Row ${conflict.targetRowIndex} ('${conflict.targetMainWord}') as ${conflict.targetField}.",
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF78350F),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onEdit()
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Edit This Row", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = Slate600)
            }
        }
    )
}

@Composable
fun CsvExportDialog(
    sheetTitle: String,
    rowCount: Int,
    csvPreview: String,
    onDismiss: () -> Unit,
    onShare: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Download, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export as CSV", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Slate900)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Export '$sheetTitle' ($rowCount rows) as standard CSV for Excel, Google Sheets, or vocabulary study apps.",
                    fontSize = 13.sp,
                    color = Slate600
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text("CSV Content Preview:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Slate800)
                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 180.dp)
                        .background(Slate50, RoundedCornerShape(8.dp))
                        .border(1.dp, Slate200, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = csvPreview,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = Slate800
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onShare,
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("confirm_export_csv_button")
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share CSV File", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = Slate600)
            }
        }
    )
}

@Composable
fun GeminiApiKeyDialog(
    currentCustomKey: String,
    keySourceDescription: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var apiKeyText by remember { mutableStateOf(currentCustomKey) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrandPrimary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Gemini AI Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Slate900)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = BrandPrimaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Status: $keySourceDescription",
                        fontSize = 12.sp,
                        color = BrandPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "The Gemini AI client uses 'gemini-3.5-flash' to automatically generate accurate synonyms and antonyms in the background when words are added.",
                    fontSize = 12.5.sp,
                    color = Slate600
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text("Custom Gemini API Key:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Slate800)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = apiKeyText,
                    onValueChange = { apiKeyText = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    placeholder = { Text("Paste your Gemini API key (AIzaSy...)", fontSize = 12.5.sp, color = Slate400) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = BrandPrimary,
                        focusedBorderColor = BrandPrimary,
                        unfocusedBorderColor = Slate300,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_api_key_input")
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Keys can also be configured via the Secrets panel in AI Studio as GEMINI_API_KEY.",
                    fontSize = 11.sp,
                    color = Slate400
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(apiKeyText) },
                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("save_gemini_key_button")
            ) {
                Text("Save Key", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = Slate600)
            }
        }
    )
}

@Composable
fun WebSemanticMatchDialog(
    match: WebSemanticMatch,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = WebMatchIndigoBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "Web Discovery",
                            tint = WebMatchIndigo,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Gemini Web Match Alert",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = Slate900
                    )
                    Text(
                        text = "Unlisted relationship detected via web dictionary",
                        fontSize = 11.5.sp,
                        color = Slate500
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Gemini searched broader web dictionary knowledge for previous spreadsheet rows and found an unlisted connection:",
                    fontSize = 13.sp,
                    color = Slate700
                )
                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = WebMatchIndigoBg),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WebMatchIndigoBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("web_match_details_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (match.relationship.contains("synonym")) SynonymGreen else AntonymRose
                            ) {
                                Text(
                                    text = match.relationship.uppercase(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "\"${match.newWord}\" ➔ Row #${match.matchedRowIndex} (\"${match.matchedMainWord}\")",
                                fontWeight = FontWeight.Bold,
                                color = WebMatchIndigoDark,
                                fontSize = 13.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = match.explanation,
                            color = Slate700,
                            fontSize = 12.5.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "💡 Notice: Even though '${match.newWord}' was not listed on the spreadsheet, Gemini identified it via online lexical grounding.",
                                fontSize = 11.sp,
                                color = Slate600,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = WebMatchIndigo),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("dismiss_web_match_button")
            ) {
                Text("Understood", fontWeight = FontWeight.Bold)
            }
        }
    )
}

