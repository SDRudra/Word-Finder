package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.gemini.ApiKeyManager
import com.example.data.gemini.GeminiService
import com.example.data.local.AppDatabase
import com.example.data.local.RowEntity
import com.example.data.local.SheetEntity
import com.example.data.model.DuplicateConflict
import com.example.data.model.WebSemanticMatch
import com.example.data.repository.SpreadsheetRepository
import com.example.data.theme.ThemeMode
import com.example.data.theme.ThemePreferences
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class UiEvent {
    data class ShowToast(val message: String) : UiEvent()
    data class ShareCsv(val intent: Intent) : UiEvent()
    data class WebMatchDiscovered(val match: WebSemanticMatch) : UiEvent()
}

@OptIn(ExperimentalCoroutinesApi::class)
class SpreadsheetViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val apiKeyManager = ApiKeyManager(application)
    val themePreferences = ThemePreferences(application)
    private val geminiService = GeminiService { apiKeyManager.getActiveApiKey() }

    val themeMode: StateFlow<ThemeMode> = themePreferences.themeMode

    fun setThemeMode(mode: ThemeMode) {
        themePreferences.setThemeMode(mode)
    }

    // App Navigation State: "home" or "spreadsheet"
    private val _currentScreen = MutableStateFlow("home")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    fun navigateToHome() {
        _currentScreen.value = "home"
    }

    fun navigateToSpreadsheet(sheetId: Long? = null) {
        if (sheetId != null) {
            _activeSheetId.value = sheetId
        } else if (_activeSheetId.value == null && allSheets.value.isNotEmpty()) {
            _activeSheetId.value = allSheets.value.first().id
        }
        _currentScreen.value = "spreadsheet"
    }

    val repository = SpreadsheetRepository(
        sheetDao = database.sheetDao(),
        rowDao = database.rowDao(),
        dictionaryDao = database.dictionaryDao(),
        geminiService = geminiService,
        appScope = viewModelScope
    )

    private val _eventFlow = MutableSharedFlow<UiEvent>()
    val eventFlow: SharedFlow<UiEvent> = _eventFlow.asSharedFlow()

    // All available sheets
    val allSheets: StateFlow<List<SheetEntity>> = repository.getAllSheets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently active sheet ID
    private val _activeSheetId = MutableStateFlow<Long?>(null)
    val activeSheetId: StateFlow<Long?> = _activeSheetId.asStateFlow()

    init {
        // Automatically select first sheet when sheets load
        viewModelScope.launch {
            allSheets.collect { sheets ->
                if (_activeSheetId.value == null && sheets.isNotEmpty()) {
                    _activeSheetId.value = sheets.first().id
                }
            }
        }
    }

    // Search query within the spreadsheet
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Filter to only show rows with duplicate warnings
    private val _filterOnlyDuplicates = MutableStateFlow(false)
    val filterOnlyDuplicates: StateFlow<Boolean> = _filterOnlyDuplicates.asStateFlow()

    // Raw rows for current active sheet
    val currentSheetRows: StateFlow<List<RowEntity>> = _activeSheetId.flatMapLatest { sheetId ->
        if (sheetId != null) {
            repository.getRowsForSheet(sheetId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Map of rowId to its duplicate conflicts
    val duplicateMap: StateFlow<Map<Long, List<DuplicateConflict>>> = currentSheetRows.map { rows ->
        repository.detectDuplicates(rows)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Total number of rows that have duplicate conflicts
    val duplicateRowCount: StateFlow<Int> = duplicateMap.map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Filtered rows based on search query and duplicate filter
    val filteredRows: StateFlow<List<RowEntity>> = combine(
        currentSheetRows,
        _searchQuery,
        _filterOnlyDuplicates,
        duplicateMap
    ) { rows, query, onlyDupes, dupes ->
        rows.filter { row ->
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                row.mainWord.contains(query, ignoreCase = true) ||
                row.synonyms.contains(query, ignoreCase = true) ||
                row.antonyms.contains(query, ignoreCase = true)
            }
            val matchesDupe = if (onlyDupes) {
                dupes.containsKey(row.id)
            } else {
                true
            }
            matchesQuery && matchesDupe
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Live input word for adding a new row
    private val _inputWord = MutableStateFlow("")
    val inputWord: StateFlow<String> = _inputWord.asStateFlow()

    // Real-time pre-check duplicate warning for the live input word
    val inputDuplicateWarning: StateFlow<DuplicateConflict?> = combine(
        _inputWord,
        currentSheetRows
    ) { word, rows ->
        val trimmed = word.trim().lowercase()
        if (trimmed.isBlank()) return@combine null

        for (row in rows) {
            if (row.mainWord.trim().equals(trimmed, ignoreCase = true)) {
                return@combine DuplicateConflict(
                    conflictingWord = trimmed,
                    sourceField = "Main Word",
                    targetRowIndex = row.position,
                    targetField = "Main Word",
                    targetMainWord = row.mainWord
                )
            }
            val syns = row.synonyms.split(",", ";").map { it.trim().lowercase() }
            if (syns.contains(trimmed)) {
                return@combine DuplicateConflict(
                    conflictingWord = trimmed,
                    sourceField = "Main Word",
                    targetRowIndex = row.position,
                    targetField = "Synonym",
                    targetMainWord = row.mainWord
                )
            }
            val ants = row.antonyms.split(",", ";").map { it.trim().lowercase() }
            if (ants.contains(trimmed)) {
                return@combine DuplicateConflict(
                    conflictingWord = trimmed,
                    sourceField = "Main Word",
                    targetRowIndex = row.position,
                    targetField = "Antonym",
                    targetMainWord = row.mainWord
                )
            }
        }
        null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun onInputWordChanged(newWord: String) {
        _inputWord.value = newWord
    }

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun toggleFilterOnlyDuplicates() {
        _filterOnlyDuplicates.value = !_filterOnlyDuplicates.value
    }

    fun selectSheet(sheetId: Long) {
        _activeSheetId.value = sheetId
    }

    fun createNewSheet(title: String) {
        viewModelScope.launch {
            val newId = repository.createSheet(title)
            _activeSheetId.value = newId
            _eventFlow.emit(UiEvent.ShowToast("Created sheet '$title'"))
        }
    }

    fun createNewSheetAndOpen(title: String) {
        viewModelScope.launch {
            val newId = repository.createSheet(title)
            _activeSheetId.value = newId
            _currentScreen.value = "spreadsheet"
            _eventFlow.emit(UiEvent.ShowToast("Created sheet '$title'"))
        }
    }

    fun renameSheet(sheetId: Long, newTitle: String) {
        viewModelScope.launch {
            repository.updateSheetTitle(sheetId, newTitle)
            _eventFlow.emit(UiEvent.ShowToast("Sheet renamed"))
        }
    }

    fun deleteSheet(sheetId: Long) {
        viewModelScope.launch {
            repository.deleteSheet(sheetId)
            val remaining = allSheets.value.filter { it.id != sheetId }
            _activeSheetId.value = remaining.firstOrNull()?.id
            _eventFlow.emit(UiEvent.ShowToast("Sheet deleted"))
        }
    }

    // Active web semantic match alert (when Gemini finds an unlisted match on the web)
    private val _activeWebSemanticMatch = MutableStateFlow<WebSemanticMatch?>(null)
    val activeWebSemanticMatch: StateFlow<WebSemanticMatch?> = _activeWebSemanticMatch.asStateFlow()

    fun dismissWebSemanticMatch() {
        _activeWebSemanticMatch.value = null
    }

    fun addRow(wordToAdd: String? = null) {
        val sheetId = _activeSheetId.value ?: return
        val word = (wordToAdd ?: _inputWord.value).trim()
        if (word.isBlank()) {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Please enter a main word first"))
            }
            return
        }

        viewModelScope.launch {
            repository.addRowWithWord(sheetId, word) { webMatch ->
                _activeWebSemanticMatch.value = webMatch
                viewModelScope.launch {
                    _eventFlow.emit(UiEvent.WebMatchDiscovered(webMatch))
                }
            }
            _inputWord.value = ""
            _eventFlow.emit(UiEvent.ShowToast("Added '$word' • Gemini AI analyzing web synonyms/antonyms"))
        }
    }

    fun updateRow(rowId: Long, mainWord: String, synonyms: String, antonyms: String) {
        viewModelScope.launch {
            repository.updateRowCells(rowId, mainWord, synonyms, antonyms, retriggerAiIfChanged = true)
        }
    }

    fun deleteRow(rowId: Long) {
        viewModelScope.launch {
            repository.deleteRow(rowId)
            _eventFlow.emit(UiEvent.ShowToast("Row deleted"))
        }
    }

    fun clearSheet() {
        val sheetId = _activeSheetId.value ?: return
        viewModelScope.launch {
            repository.clearSheetRows(sheetId)
            _activeWebSemanticMatch.value = null
            _eventFlow.emit(UiEvent.ShowToast("Sheet cleared"))
        }
    }

    fun retryAiLookup(rowId: Long) {
        viewModelScope.launch {
            repository.retryGeminiLookup(rowId) { webMatch ->
                _activeWebSemanticMatch.value = webMatch
                viewModelScope.launch {
                    _eventFlow.emit(UiEvent.WebMatchDiscovered(webMatch))
                }
            }
            _eventFlow.emit(UiEvent.ShowToast("Retrying Gemini AI lookup & web analysis..."))
        }
    }

    fun saveApiKey(newKey: String) {
        apiKeyManager.saveUserApiKey(newKey)
        viewModelScope.launch {
            _eventFlow.emit(UiEvent.ShowToast("Gemini API key updated"))
        }
    }

    fun exportSheetAsCsv(context: Context) {
        val sheetId = _activeSheetId.value ?: return
        val activeSheet = allSheets.value.find { it.id == sheetId }
        val sheetTitle = activeSheet?.title ?: "Synonym_Antonym_Spreadsheet"
        val rows = currentSheetRows.value

        if (rows.isEmpty()) {
            viewModelScope.launch {
                _eventFlow.emit(UiEvent.ShowToast("Spreadsheet is empty, nothing to export"))
            }
            return
        }

        viewModelScope.launch {
            try {
                val csvUri = repository.createCsvFile(context, sheetTitle, rows)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, csvUri)
                    putExtra(Intent.EXTRA_SUBJECT, "$sheetTitle - Synonym & Antonym Spreadsheet")
                    putExtra(Intent.EXTRA_TEXT, "Exported spreadsheet: $sheetTitle (${rows.size} rows)")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(shareIntent, "Export CSV File via")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                _eventFlow.emit(UiEvent.ShareCsv(chooser))
            } catch (e: Exception) {
                _eventFlow.emit(UiEvent.ShowToast("Export failed: ${e.message}"))
            }
        }
    }

    fun getCsvPreview(): String {
        return repository.generateCsv(currentSheetRows.value)
    }
}
