package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.RowEntity
import com.example.data.local.SheetEntity
import com.example.data.model.DuplicateConflict
import com.example.ui.components.AddSheetDialog
import com.example.ui.components.CsvExportDialog
import com.example.ui.components.DuplicateDetailsDialog
import com.example.ui.components.EditRowDialog
import com.example.ui.components.GeminiApiKeyDialog
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.LiquidGlassPill
import com.example.ui.components.RenameSheetDialog
import com.example.ui.components.SpreadsheetGrid
import com.example.ui.components.WebSemanticMatchDialog
import com.example.ui.theme.AntonymRose
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandPrimaryContainer
import com.example.ui.theme.BrandPrimaryDark
import com.example.ui.theme.BrandPrimaryLight
import com.example.ui.theme.SheetCellBorder
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.SynonymGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.ui.theme.WarningAmberBorder
import com.example.ui.theme.WebMatchIndigo
import com.example.ui.theme.WebMatchIndigoBg
import com.example.ui.theme.WebMatchIndigoBorder
import com.example.ui.theme.WebMatchIndigoDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpreadsheetScreen(
    viewModel: SpreadsheetViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    val allSheets by viewModel.allSheets.collectAsStateWithLifecycle()
    val activeSheetId by viewModel.activeSheetId.collectAsStateWithLifecycle()
    val filteredRows by viewModel.filteredRows.collectAsStateWithLifecycle()
    val totalRows by viewModel.currentSheetRows.collectAsStateWithLifecycle()
    val duplicateMap by viewModel.duplicateMap.collectAsStateWithLifecycle()
    val duplicateRowCount by viewModel.duplicateRowCount.collectAsStateWithLifecycle()
    val inputWord by viewModel.inputWord.collectAsStateWithLifecycle()
    val inputDuplicateWarning by viewModel.inputDuplicateWarning.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val filterOnlyDuplicates by viewModel.filterOnlyDuplicates.collectAsStateWithLifecycle()
    val activeWebSemanticMatch by viewModel.activeWebSemanticMatch.collectAsStateWithLifecycle()

    var showSearchRow by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showAddSheetDialog by remember { mutableStateOf(false) }
    var showRenameSheetDialog by remember { mutableStateOf(false) }
    var showCsvDialog by remember { mutableStateOf(false) }
    var showGeminiConfigDialog by remember { mutableStateOf(false) }

    var selectedRowForEdit by remember { mutableStateOf<RowEntity?>(null) }
    var selectedRowForDuplicateDetails by remember { mutableStateOf<Pair<RowEntity, List<DuplicateConflict>>?>(null) }

    val activeSheet = allSheets.find { it.id == activeSheetId }

    // Handle single events (Toasts, Share dialogs)
    LaunchedEffect(Unit) {
        viewModel.eventFlow.collect { event ->
            when (event) {
                is UiEvent.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
                is UiEvent.ShareCsv -> {
                    context.startActivity(event.intent)
                }
                is UiEvent.WebMatchDiscovered -> {
                    Toast.makeText(
                        context,
                        "🌐 Gemini Web Match: '${event.match.newWord}' is a ${event.match.relationship} of Row ${event.match.matchedRowIndex} ('${event.match.matchedMainWord}')!",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateToHome() },
                        modifier = Modifier.testTag("back_to_home_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Projects",
                            tint = Slate700
                        )
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = BrandPrimaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = null,
                                    tint = BrandPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Synonym & Antonym",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp,
                                    color = Slate900,
                                    letterSpacing = (-0.3).sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Slate100,
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Slate300)
                                ) {
                                    Text(
                                        text = "STUDIO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Slate600,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = "${activeSheet?.title ?: "Vocabulary Sheet"} • ${totalRows.size} entries",
                                fontSize = 11.5.sp,
                                color = Slate500,
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }
                },
                actions = {
                    // Export CSV Action Pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Slate100,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
                        modifier = Modifier
                            .clickable { showCsvDialog = true }
                            .testTag("export_csv_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Export CSV",
                                tint = BrandPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "CSV",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandPrimaryDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Search Toggle
                    IconButton(
                        onClick = { showSearchRow = !showSearchRow },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = if (showSearchRow) Icons.Default.Close else Icons.Default.Search,
                            contentDescription = "Search Words",
                            tint = if (showSearchRow) BrandPrimary else Slate700,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // More Options Menu
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = "More Options",
                            tint = Slate700,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("New Sheet Tab", fontWeight = FontWeight.Medium) },
                            leadingIcon = { Icon(Icons.Default.Add, contentDescription = null, tint = BrandPrimary) },
                            onClick = {
                                showMenu = false
                                showAddSheetDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Rename Sheet Tab") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                showRenameSheetDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Gemini AI Settings") },
                            leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrandPrimary) },
                            onClick = {
                                showMenu = false
                                showGeminiConfigDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Clear All Rows") },
                            leadingIcon = { Icon(Icons.Default.Clear, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                viewModel.clearSheet()
                            }
                        )
                        if (allSheets.size > 1 && activeSheetId != null) {
                            DropdownMenuItem(
                                text = { Text("Delete This Tab", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showMenu = false
                                    viewModel.deleteSheet(activeSheetId!!)
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFFAFAFB))
                .imePadding()
        ) {
            // Modern Workspace Tab Bar
            SheetTabBar(
                sheets = allSheets,
                activeSheetId = activeSheetId,
                onSelectSheet = { viewModel.selectSheet(it) },
                onAddSheet = { showAddSheetDialog = true }
            )

            // Dynamic Stats Ribbon
            StatsRibbon(
                totalRowsCount = totalRows.size,
                duplicateCount = duplicateRowCount,
                filterOnlyDuplicates = filterOnlyDuplicates,
                onToggleFilterDuplicates = { viewModel.toggleFilterOnlyDuplicates() }
            )

            // Search Bar (Smoothly Animated)
            AnimatedVisibility(
                visible = showSearchRow,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                Surface(
                    color = Color.White,
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.onSearchQueryChanged(it) },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Slate900,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Normal
                            ),
                            placeholder = { Text("Search words, synonyms, or antonyms...", fontSize = 13.sp, color = Slate500) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp), tint = Slate500)
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear search", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Slate900,
                                unfocusedTextColor = Slate900,
                                cursorColor = BrandPrimary,
                                focusedBorderColor = BrandPrimary,
                                unfocusedBorderColor = Slate300,
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Slate50,
                                focusedPlaceholderColor = Slate500,
                                unfocusedPlaceholderColor = Slate500
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("search_input")
                        )
                    }
                }
            }

            // Web Semantic Discovery Alert Banner (Unlisted web synonym/antonym match)
            activeWebSemanticMatch?.let { match ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = WebMatchIndigoBg),
                    shape = RoundedCornerShape(0.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WebMatchIndigoBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("web_match_alert_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Web Match alert",
                            tint = WebMatchIndigo,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini Web Grounding Alert: Unlisted ${match.relationship.replaceFirstChar { it.uppercase() }}",
                                fontWeight = FontWeight.Bold,
                                color = WebMatchIndigoDark,
                                fontSize = 12.5.sp
                            )
                            Text(
                                text = "'${match.newWord}' matches Row ${match.matchedRowIndex} ('${match.matchedMainWord}') via web dictionary search.",
                                color = Slate700,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { viewModel.dismissWebSemanticMatch() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss web alert",
                                tint = Slate600,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Duplicate Conflict Alert Banner
            if (duplicateRowCount > 0) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarningAmberBg),
                    shape = RoundedCornerShape(0.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmberBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("duplicate_warning_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = "Duplicate alert",
                            tint = WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cross-Column Duplicate Detected",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF78350F),
                                fontSize = 12.5.sp
                            )
                            Text(
                                text = "$duplicateRowCount row(s) share matching words between main, synonym, or antonym cells.",
                                color = Color(0xFF92400E),
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        FilterChip(
                            selected = filterOnlyDuplicates,
                            onClick = { viewModel.toggleFilterOnlyDuplicates() },
                            label = {
                                Text(
                                    text = if (filterOnlyDuplicates) "Show All" else "Conflicts",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(13.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WarningAmber,
                                selectedLabelColor = Color.White,
                                containerColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = filterOnlyDuplicates,
                                borderColor = WarningAmberBorder,
                                selectedBorderColor = WarningAmber
                            ),
                            modifier = Modifier.testTag("toggle_filter_duplicates_button")
                        )
                    }
                }
            }

            // Main Spreadsheet Grid
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(Color.White)
            ) {
                SpreadsheetGrid(
                    rows = filteredRows,
                    duplicateMap = duplicateMap,
                    onRowClick = { row -> selectedRowForEdit = row },
                    onDeleteRow = { id -> viewModel.deleteRow(id) },
                    onShowDuplicateDetails = { row, conflicts ->
                        selectedRowForDuplicateDetails = Pair(row, conflicts)
                    },
                    onStarterWordClick = { starterWord ->
                        viewModel.addRow(starterWord)
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Bottom Input Command Bar
            BottomInputBar(
                inputWord = inputWord,
                duplicateWarning = inputDuplicateWarning,
                onWordChange = { viewModel.onInputWordChanged(it) },
                onAddWord = {
                    viewModel.addRow()
                    focusManager.clearFocus()
                }
            )
        }
    }

    // Interactive Dialogs
    if (showAddSheetDialog) {
        AddSheetDialog(
            onDismiss = { showAddSheetDialog = false },
            onConfirm = { title ->
                showAddSheetDialog = false
                viewModel.createNewSheet(title)
            }
        )
    }

    if (showRenameSheetDialog && activeSheet != null) {
        RenameSheetDialog(
            currentTitle = activeSheet.title,
            onDismiss = { showRenameSheetDialog = false },
            onConfirm = { newTitle ->
                showRenameSheetDialog = false
                viewModel.renameSheet(activeSheet.id, newTitle)
            }
        )
    }

    if (showCsvDialog && activeSheet != null) {
        CsvExportDialog(
            sheetTitle = activeSheet.title,
            rowCount = totalRows.size,
            csvPreview = viewModel.getCsvPreview(),
            onDismiss = { showCsvDialog = false },
            onShare = {
                showCsvDialog = false
                viewModel.exportSheetAsCsv(context)
            }
        )
    }

    if (showGeminiConfigDialog) {
        GeminiApiKeyDialog(
            currentCustomKey = viewModel.apiKeyManager.getSavedUserKey(),
            keySourceDescription = viewModel.apiKeyManager.getKeySourceDescription(),
            onDismiss = { showGeminiConfigDialog = false },
            onSave = { newKey ->
                showGeminiConfigDialog = false
                viewModel.saveApiKey(newKey)
            }
        )
    }

    selectedRowForEdit?.let { row ->
        EditRowDialog(
            row = row,
            conflicts = duplicateMap[row.id],
            onDismiss = { selectedRowForEdit = null },
            onSave = { mainWord, synonyms, antonyms ->
                viewModel.updateRow(row.id, mainWord, synonyms, antonyms)
                selectedRowForEdit = null
            },
            onRetryAi = {
                viewModel.retryAiLookup(row.id)
            }
        )
    }

    selectedRowForDuplicateDetails?.let { (row, conflicts) ->
        DuplicateDetailsDialog(
            row = row,
            conflicts = conflicts,
            onDismiss = { selectedRowForDuplicateDetails = null },
            onEdit = {
                val r = row
                selectedRowForDuplicateDetails = null
                selectedRowForEdit = r
            }
        )
    }

    activeWebSemanticMatch?.let { match ->
        WebSemanticMatchDialog(
            match = match,
            onDismiss = { viewModel.dismissWebSemanticMatch() }
        )
    }
}

@Composable
private fun SheetTabBar(
    sheets: List<SheetEntity>,
    activeSheetId: Long?,
    onSelectSheet: (Long) -> Unit,
    onAddSheet: () -> Unit
) {
    Surface(
        color = Slate100,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            sheets.forEach { sheet ->
                val isSelected = sheet.id == activeSheetId
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) Color.White else Color.Transparent,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Slate300) else null,
                    shadowElevation = if (isSelected) 1.dp else 0.dp,
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSelectSheet(sheet.id) }
                        .testTag("sheet_tab_${sheet.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.TableChart,
                            contentDescription = null,
                            tint = if (isSelected) BrandPrimary else Slate400,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = sheet.title,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Slate900 else Slate600,
                            fontSize = 12.5.sp
                        )
                    }
                }
            }

            // Add Tab Button
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Slate200.copy(alpha = 0.6f),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onAddSheet() }
                    .testTag("add_sheet_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add New Sheet Tab",
                        tint = Slate700,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "New Tab",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate700
                    )
                }
            }
        }
    }
}

@Composable
private fun StatsRibbon(
    totalRowsCount: Int,
    duplicateCount: Int,
    filterOnlyDuplicates: Boolean,
    onToggleFilterDuplicates: () -> Unit
) {
    Surface(
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, SheetCellBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Count badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Slate100,
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Slate200)
                ) {
                    Text(
                        text = "$totalRowsCount words logged",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate700,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Conflict Status Indicator
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (duplicateCount == 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SynonymGreen,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "No duplicate conflicts",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = SynonymGreen
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (filterOnlyDuplicates) WarningAmber else WarningAmberBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmberBorder),
                        modifier = Modifier.clickable { onToggleFilterDuplicates() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = if (filterOnlyDuplicates) Color.White else WarningAmber,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$duplicateCount duplicate warning${if (duplicateCount > 1) "s" else ""}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (filterOnlyDuplicates) Color.White else WarningAmber
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomInputBar(
    inputWord: String,
    duplicateWarning: DuplicateConflict?,
    onWordChange: (String) -> Unit,
    onAddWord: () -> Unit
) {
    Surface(
        color = Color.White,
        shadowElevation = 10.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            // Live Duplicate Warning Toast
            AnimatedVisibility(
                visible = duplicateWarning != null,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                if (duplicateWarning != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarningAmberBg),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmberBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("input_duplicate_warning_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = WarningAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Duplicate Alert: '${duplicateWarning.conflictingWord}' is already on Row ${duplicateWarning.targetRowIndex} as ${duplicateWarning.targetField}!",
                                color = Color(0xFF78350F),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputWord,
                    onValueChange = onWordChange,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = Slate900,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    placeholder = {
                        Text(
                            text = "Enter main word (e.g. 'candid', 'diligent')...",
                            fontSize = 13.5.sp,
                            color = Slate500
                        )
                    },
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = if (inputWord.isNotBlank()) BrandPrimary else Slate500,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onAddWord() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        cursorColor = BrandPrimary,
                        focusedBorderColor = BrandPrimary,
                        unfocusedBorderColor = Slate400,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedPlaceholderColor = Slate500,
                        unfocusedPlaceholderColor = Slate500
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("main_word_input")
                )

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onAddWord,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrandPrimary,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                    modifier = Modifier.testTag("add_row_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Auto-Fill",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, start = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = BrandPrimary,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Gemini checks spreadsheet & web dictionary for unlisted synonym/antonym matches",
                    fontSize = 10.5.sp,
                    color = Slate500,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
