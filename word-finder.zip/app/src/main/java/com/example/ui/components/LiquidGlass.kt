package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Reusable Liquid Glass Container with specular highlight, frosted gradient body,
 * and high-end translucent glass borders.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    backgroundColor: Color = Color.White.copy(alpha = 0.88f),
    borderColor: Color = Color.White.copy(alpha = 0.95f),
    elevation: Dp = 6.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = shape,
                ambientColor = Color(0x1A0F172A),
                spotColor = Color(0x240F172A)
            )
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.98f),
                        backgroundColor,
                        backgroundColor.copy(alpha = 0.82f)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        borderColor,
                        Color(0xFFE2E8F0).copy(alpha = 0.7f),
                        Color(0xFFCBD5E1).copy(alpha = 0.45f)
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

/**
 * Floating Liquid Glass Pill or Button container with glistening specular highlights.
 */
@Composable
fun LiquidGlassPill(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    baseColor: Color = Color.White.copy(alpha = 0.88f),
    highlightColor: Color = Color.White,
    borderStrokeWidth: Dp = 1.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        highlightColor.copy(alpha = 0.98f),
                        baseColor,
                        baseColor.copy(alpha = 0.78f)
                    )
                )
            )
            .border(
                width = borderStrokeWidth,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White,
                        Color(0xFFE2E8F0).copy(alpha = 0.75f)
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

/**
 * Custom Liquid Glass Dialog Container that wraps dialog content in an elegant,
 * translucent, ultra-crisp frosted glass card.
 */
@Composable
fun LiquidGlassDialog(
    onDismissRequest: () -> Unit,
    properties: DialogProperties = DialogProperties(usePlatformDefaultWidth = false),
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    content: @Composable () -> Unit
) {
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = properties
    ) {
        Box(
            modifier = modifier
                .shadow(
                    elevation = 16.dp,
                    shape = shape,
                    ambientColor = Color(0x260F172A),
                    spotColor = Color(0x330F172A)
                )
                .clip(shape)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.96f),
                            Color(0xFFF8FAFC).copy(alpha = 0.92f),
                            Color(0xFFF1F5F9).copy(alpha = 0.88f)
                        )
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White,
                            Color(0xFFE2E8F0).copy(alpha = 0.8f),
                            Color(0xFFCBD5E1).copy(alpha = 0.5f)
                        )
                    ),
                    shape = shape
                )
        ) {
            content()
        }
    }
}
