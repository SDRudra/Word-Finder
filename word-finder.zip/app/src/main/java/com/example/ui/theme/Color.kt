package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Primary Colors - Deep Modern Indigo / Cyan / Teal
val BrandPrimary = Color(0xFF0F766E)
val BrandPrimaryLight = Color(0xFF14B8A6)
val BrandPrimaryDark = Color(0xFF115E59)
val BrandPrimaryContainer = Color(0xFFCCFBF1)
val BrandOnPrimaryContainer = Color(0xFF0F766E)

// Slate Neutrals
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Synonyms Palette (Emerald / Mint)
val SynonymGreen = Color(0xFF047857)
val SynonymGreenBg = Color(0xFFECFDF5)
val SynonymGreenBorder = Color(0xFFA7F3D0)
val SynonymGreenBadge = Color(0xFF059669)

// Antonyms Palette (Rose / Coral)
val AntonymRose = Color(0xFFBE123C)
val AntonymRoseBg = Color(0xFFFFF1F2)
val AntonymRoseBorder = Color(0xFFFECDD3)
val AntonymRoseBadge = Color(0xFFE11D48)

// Duplicate Warning Palette (Amber / Gold)
val WarningAmber = Color(0xFFB45309)
val WarningAmberBg = Color(0xFFFFFBEB)
val WarningAmberBorder = Color(0xFFFCD34D)
val WarningAmberCard = Color(0xFFFEF3C7)

// Web Semantic Search Alert Palette (Indigo / Purple)
val WebMatchIndigo = Color(0xFF4338CA)
val WebMatchIndigoBg = Color(0xFFEEF2FF)
val WebMatchIndigoBorder = Color(0xFFC7D2FE)
val WebMatchIndigoDark = Color(0xFF312E81)

// Liquid Glass Effects & Premium Minimalist Tokens
val GlassCanvasBg = Color(0xFF0D1117)
val GlassSurface = Color(0xCC161B22) // 80% frosted dark surface
val GlassSurfaceElevated = Color(0xD921262D) // 85% elevated glass
val GlassSurfaceSubtle = Color(0x66161B22) // 40% subtle glass
val GlassBorder = Color(0x33FFFFFF) // Subtle specular glass edge (20% white)
val GlassBorderLight = Color(0x59FFFFFF) // Crisp highlight edge (35% white)
val GlassHighlight = Color(0x1FFFFFFF) // Top-edge liquid reflection
val GlassGlowCyan = Color(0x2600F2FE)
val GlassGlowPurple = Color(0x264FACFE)

// Light Glass Tokens (for pristine translucent overlays)
val GlassWhite85 = Color(0xD9FFFFFF)
val GlassWhite70 = Color(0xB3FFFFFF)
val GlassWhite50 = Color(0x80FFFFFF)
val GlassWhite30 = Color(0x4DFFFFFF)
val GlassWhiteBorder = Color(0x66FFFFFF)

// Spreadsheet Grid System
val SheetHeaderBg = Color(0xFFF8FAFC)
val SheetHeaderBorder = Color(0xFFE2E8F0)
val SheetRowEven = Color(0xFFFFFFFF)
val SheetRowOdd = Color(0xFFFBFDFF)
val SheetRowHover = Color(0xFFF0FDF4)
val SheetCellBorder = Color(0xFFE2E8F0)
val SheetGutterBg = Color(0xFFF1F5F9)

// Legacy alias compatibility
val SlateNavy = Slate900
val SlateBlue = Slate800
val PrimaryTeal = BrandPrimary
val PrimaryTealDark = BrandPrimaryDark
val PrimaryTealLight = BrandPrimaryContainer
val CellBorderLight = SheetCellBorder
val CellHeaderBgLight = SheetHeaderBg
val CellRowEvenLight = SheetRowEven
val CellRowOddLight = SheetRowOdd

val DarkBg = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF121B2D)
val DarkSurfaceElevated = Color(0xFF1B283E)
val CellBorderDark = Color(0xFF273852)
val CellHeaderBgDark = Color(0xFF16233B)
val CellRowEvenDark = Color(0xFF0E1626)
val CellRowOddDark = Color(0xFF131E33)
val SynonymGreenDark = Color(0xFF34D399)
val SynonymGreenBgDark = Color(0xFF064E3B)
val AntonymRoseDark = Color(0xFFFB7185)
val AntonymRoseBgDark = Color(0xFF4C0519)
val WarningAmberDark = Color(0xFFFBBF24)
val WarningAmberBgDark = Color(0xFF451A03)
