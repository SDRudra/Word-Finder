package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.RowEntity
import com.example.data.model.DuplicateConflict
import com.example.ui.theme.AntonymRose
import com.example.ui.theme.AntonymRoseBg
import com.example.ui.theme.AntonymRoseBorder
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandPrimaryContainer
import com.example.ui.theme.BrandPrimaryDark
import com.example.ui.theme.BrandPrimaryLight
import com.example.ui.theme.SheetCellBorder
import com.example.ui.theme.SheetGutterBg
import com.example.ui.theme.SheetHeaderBg
import com.example.ui.theme.SheetRowEven
import com.example.ui.theme.SheetRowOdd
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.SynonymGreen
import com.example.ui.theme.SynonymGreenBg
import com.example.ui.theme.SynonymGreenBorder
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.ui.theme.WarningAmberBorder

// Standard spreadsheet column widths
private val COL_ROW_NUM_WIDTH = 52.dp
private val COL_MAIN_WORD_WIDTH = 145.dp
private val COL_SYNONYMS_WIDTH = 230.dp
private val COL_ANTONYMS_WIDTH = 230.dp
private val COL_STATUS_WIDTH = 115.dp
private val COL_ACTIONS_WIDTH = 90.dp

val TOTAL_GRID_WIDTH = COL_ROW_NUM_WIDTH + COL_MAIN_WORD_WIDTH + COL_SYNONYMS_WIDTH +
        COL_ANTONYMS_WIDTH + COL_STATUS_WIDTH + COL_ACTIONS_WIDTH

@Composable
fun SpreadsheetGrid(
    rows: List<RowEntity>,
    duplicateMap: Map<Long, List<DuplicateConflict>>,
    onRowClick: (RowEntity) -> Unit,
    onDeleteRow: (Long) -> Unit,
    onShowDuplicateDetails: (RowEntity, List<DuplicateConflict>) -> Unit,
    onStarterWordClick: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val horizontalScrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .horizontalScroll(horizontalScrollState)
            .testTag("spreadsheet_grid")
    ) {
        Column(
            modifier = Modifier
                .width(TOTAL_GRID_WIDTH)
                .fillMaxHeight()
        ) {
            // Sticky Grid Column Header Bar
            SpreadsheetHeader()

            if (rows.isEmpty()) {
                EmptySpreadsheetPlaceholder(onStarterWordClick = onStarterWordClick)
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    itemsIndexed(
                        items = rows,
                        key = { _, row -> row.id }
                    ) { index, row ->
                        val conflicts = duplicateMap[row.id]
                        SpreadsheetRowItem(
                            index = index + 1,
                            row = row,
                            conflicts = conflicts,
                            onClick = { onRowClick(row) },
                            onDelete = { onDeleteRow(row.id) },
                            onWarningClick = {
                                if (!conflicts.isNullOrEmpty()) {
                                    onShowDuplicateDetails(row, conflicts)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SpreadsheetHeader() {
    Surface(
        color = SheetHeaderBg,
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SheetCellBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderCell("#", COL_ROW_NUM_WIDTH, textAlign = TextAlign.Center, subtitle = "Row")
            GridDivider()
            HeaderCell("Main Word", COL_MAIN_WORD_WIDTH, subtitle = "Col A")
            GridDivider()
            HeaderCell(
                title = "Synonyms",
                width = COL_SYNONYMS_WIDTH,
                color = SynonymGreen,
                subtitle = "Col B • Similar"
            )
            GridDivider()
            HeaderCell(
                title = "Antonyms",
                width = COL_ANTONYMS_WIDTH,
                color = AntonymRose,
                subtitle = "Col C • Opposite"
            )
            GridDivider()
            HeaderCell("Status", COL_STATUS_WIDTH, textAlign = TextAlign.Center, subtitle = "Col D")
            GridDivider()
            HeaderCell("Actions", COL_ACTIONS_WIDTH, textAlign = TextAlign.Center, subtitle = "Col E")
        }
    }
}

@Composable
private fun HeaderCell(
    title: String,
    width: androidx.compose.ui.unit.Dp,
    color: Color = Slate800,
    subtitle: String? = null,
    textAlign: TextAlign = TextAlign.Start
) {
    Box(
        modifier = Modifier
            .width(width)
            .fillMaxHeight()
            .background(SheetHeaderBg)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = when (textAlign) {
            TextAlign.Center -> Alignment.Center
            TextAlign.End -> Alignment.CenterEnd
            else -> Alignment.CenterStart
        }
    ) {
        Column(
            horizontalAlignment = when (textAlign) {
                TextAlign.Center -> Alignment.CenterHorizontally
                TextAlign.End -> Alignment.End
                else -> Alignment.Start
            }
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = color,
                maxLines = 1
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 9.sp,
                    color = Slate400,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun SpreadsheetRowItem(
    index: Int,
    row: RowEntity,
    conflicts: List<DuplicateConflict>?,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onWarningClick: () -> Unit
) {
    val hasConflict = !conflicts.isNullOrEmpty()
    val isEven = index % 2 == 0

    val rowBg = when {
        hasConflict -> WarningAmberBg
        isEven -> SheetRowEven
        else -> SheetRowOdd
    }

    val rowBorderColor = if (hasConflict) WarningAmberBorder else SheetCellBorder

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .background(rowBg)
            .border(
                width = if (hasConflict) 1.2.dp else 0.5.dp,
                color = rowBorderColor
            )
            .clickable { onClick() }
            .testTag("spreadsheet_row_${row.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Row Number Gutter
        Box(
            modifier = Modifier
                .width(COL_ROW_NUM_WIDTH)
                .fillMaxHeight()
                .background(if (hasConflict) WarningAmberBg else SheetGutterBg)
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = index.toString(),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (hasConflict) WarningAmber else Slate500
            )
        }
        GridDivider(color = rowBorderColor)

        // Main Word Cell
        Box(
            modifier = Modifier
                .width(COL_MAIN_WORD_WIDTH)
                .fillMaxHeight()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Column(verticalArrangement = Arrangement.Center) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = row.mainWord,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Slate900,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (hasConflict) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = "Duplicate conflict",
                            tint = WarningAmber,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { onWarningClick() }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                // Source Pill Tag
                SourceTag(source = row.source)
            }
        }
        GridDivider(color = rowBorderColor)

        // Synonyms Cell
        Box(
            modifier = Modifier
                .width(COL_SYNONYMS_WIDTH)
                .fillMaxHeight()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (row.isLoadingAi) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(BrandPrimaryContainer.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(13.dp),
                        strokeWidth = 2.dp,
                        color = BrandPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Gemini generating...",
                        fontSize = 11.sp,
                        color = BrandPrimaryDark,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else if (row.synonyms.isBlank()) {
                Text(
                    text = "—",
                    fontSize = 13.sp,
                    color = Slate400,
                    modifier = Modifier.padding(start = 4.dp)
                )
            } else {
                WordChipsFlow(
                    words = row.synonyms.split(",", ";").map { it.trim() }.filter { it.isNotBlank() },
                    textColor = SynonymGreen,
                    bgColor = SynonymGreenBg,
                    borderColor = SynonymGreenBorder
                )
            }
        }
        GridDivider(color = rowBorderColor)

        // Antonyms Cell
        Box(
            modifier = Modifier
                .width(COL_ANTONYMS_WIDTH)
                .fillMaxHeight()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (row.isLoadingAi) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(BrandPrimaryContainer.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(13.dp),
                        strokeWidth = 2.dp,
                        color = BrandPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Gemini generating...",
                        fontSize = 11.sp,
                        color = BrandPrimaryDark,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else if (row.antonyms.isBlank()) {
                Text(
                    text = "—",
                    fontSize = 13.sp,
                    color = Slate400,
                    modifier = Modifier.padding(start = 4.dp)
                )
            } else {
                WordChipsFlow(
                    words = row.antonyms.split(",", ";").map { it.trim() }.filter { it.isNotBlank() },
                    textColor = AntonymRose,
                    bgColor = AntonymRoseBg,
                    borderColor = AntonymRoseBorder
                )
            }
        }
        GridDivider(color = rowBorderColor)

        // Status / Duplicate Indicator Cell
        Box(
            modifier = Modifier
                .width(COL_STATUS_WIDTH)
                .fillMaxHeight()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            if (hasConflict) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = WarningAmber,
                    shadowElevation = 1.dp,
                    modifier = Modifier.clickable { onWarningClick() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            Icons.Default.WarningAmber,
                            contentDescription = "Duplicate Warning",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Conflict",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else if (row.isLoadingAi) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = BrandPrimaryContainer
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "Gemini",
                            tint = BrandPrimary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "AI Lookup",
                            color = BrandPrimaryDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Slate100,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate200)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Ready",
                            tint = SynonymGreen,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Synced",
                            color = Slate700,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
        GridDivider(color = rowBorderColor)

        // Actions Cell
        Row(
            modifier = Modifier
                .width(COL_ACTIONS_WIDTH)
                .fillMaxHeight(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClick,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Row",
                    tint = BrandPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Row",
                    tint = Slate400,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun SourceTag(source: String) {
    val (label, icon, color) = when (source) {
        "GEMINI_AI" -> Triple("Gemini AI", Icons.Default.AutoAwesome, BrandPrimary)
        "MANUAL" -> Triple("Edited", Icons.Default.Edit, Slate600)
        else -> Triple("Dict", Icons.AutoMirrored.Filled.MenuBook, Slate500)
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(10.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = color
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WordChipsFlow(
    words: List<String>,
    textColor: Color,
    bgColor: Color,
    borderColor: Color
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        words.forEach { word ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(bgColor)
                    .border(0.8.dp, borderColor, RoundedCornerShape(6.dp))
                    .padding(horizontal = 7.dp, vertical = 2.5.dp)
            ) {
                Text(
                    text = word,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor
                )
            }
        }
    }
}

@Composable
private fun GridDivider(
    color: Color = SheetCellBorder
) {
    Box(
        modifier = Modifier
            .width(1.dp)
            .fillMaxHeight()
            .background(color)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EmptySpreadsheetPlaceholder(
    onStarterWordClick: ((String) -> Unit)? = null
) {
    val sampleWords = listOf("resilient", "curious", "eloquent", "lucid", "benevolent", "tenacious")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(BrandPrimaryLight.copy(alpha = 0.25f), BrandPrimaryContainer.copy(alpha = 0.1f))
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = BrandPrimary,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Spreadsheet is Ready",
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
            color = Slate900
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Type any word below to automatically generate synonyms and antonyms,\nor tap a sample word to try it now:",
            textAlign = TextAlign.Center,
            fontSize = 13.sp,
            color = Slate600
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Starter Chips
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 16.dp)
        ) {
            sampleWords.forEach { sampleWord ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
                    shadowElevation = 1.dp,
                    modifier = Modifier.clickable {
                        onStarterWordClick?.invoke(sampleWord)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "+ $sampleWord",
                            color = BrandPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
