package com.example

import com.example.data.local.RowEntity
import com.example.data.repository.SpreadsheetRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SpreadsheetRepositoryTest {

    @Test
    fun testDuplicateDetection_acrossColumns() {
        val rows = listOf(
            RowEntity(
                id = 1L,
                sheetId = 1L,
                position = 1,
                mainWord = "happy",
                synonyms = "joyful, cheerful, glad",
                antonyms = "sad, sorrowful, depressed"
            ),
            RowEntity(
                id = 2L,
                sheetId = 1L,
                position = 2,
                mainWord = "cheerful", // Duplicate with Row 1's synonym!
                synonyms = "happy, bright",
                antonyms = "glum, unhappy"
            )
        )

        // Mock DAOs are not needed for pure logic tests
        // Create an instance for testing pure methods
        val repo = SpreadsheetRepository(
            sheetDao = FakeSheetDao(),
            rowDao = FakeRowDao(),
            dictionaryDao = FakeDictionaryDao(),
            geminiService = com.example.data.gemini.GeminiService { "" },
            appScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined)
        )

        val duplicates = repo.detectDuplicates(rows)

        // Both rows should flag a conflict
        assertTrue(duplicates.containsKey(1L))
        assertTrue(duplicates.containsKey(2L))

        val conflictsForRow2 = duplicates[2L]
        assertNotNull(conflictsForRow2)
        assertTrue(conflictsForRow2!!.any { it.conflictingWord.equals("cheerful", ignoreCase = true) })
    }

    @Test
    fun testCsvGeneration_escapesAndFormatsProperly() {
        val rows = listOf(
            RowEntity(
                id = 1L,
                sheetId = 1L,
                position = 1,
                mainWord = "resilient",
                synonyms = "tough, strong",
                antonyms = "fragile, weak",
                source = "GEMINI_AI"
            )
        )

        val repo = SpreadsheetRepository(
            sheetDao = FakeSheetDao(),
            rowDao = FakeRowDao(),
            dictionaryDao = FakeDictionaryDao(),
            geminiService = com.example.data.gemini.GeminiService { "" },
            appScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined)
        )

        val csv = repo.generateCsv(rows)
        assertTrue(csv.contains("\"Row\",\"Main Word\",\"Synonyms\",\"Antonyms\",\"Source\""))
        assertTrue(csv.contains("\"resilient\""))
        assertTrue(csv.contains("\"tough, strong\""))
        assertTrue(csv.contains("\"fragile, weak\""))
        assertTrue(csv.contains("\"GEMINI_AI\""))
    }
}

// Minimal fakes for repository instantiation in unit test
private class FakeSheetDao : com.example.data.local.SheetDao {
    override fun getAllSheets() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.SheetEntity>())
    override suspend fun getSheetById(id: Long) = null
    override suspend fun insertSheet(sheet: com.example.data.local.SheetEntity) = 1L
    override suspend fun updateSheet(sheet: com.example.data.local.SheetEntity) {}
    override suspend fun deleteSheet(sheet: com.example.data.local.SheetEntity) {}
    override suspend fun deleteSheetById(id: Long) {}
}

private class FakeRowDao : com.example.data.local.RowDao {
    override fun getRowsForSheet(sheetId: Long) = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.RowEntity>())
    override suspend fun getRowsForSheetOnce(sheetId: Long) = emptyList<com.example.data.local.RowEntity>()
    override suspend fun getRowById(id: Long) = null
    override suspend fun getRowCountForSheet(sheetId: Long) = 0
    override suspend fun insertRow(row: com.example.data.local.RowEntity) = 1L
    override suspend fun insertRows(rows: List<com.example.data.local.RowEntity>) {}
    override suspend fun updateRow(row: com.example.data.local.RowEntity) {}
    override suspend fun deleteRow(row: com.example.data.local.RowEntity) {}
    override suspend fun deleteRowById(id: Long) {}
    override suspend fun clearSheetRows(sheetId: Long) {}
}

private class FakeDictionaryDao : com.example.data.local.DictionaryDao {
    override suspend fun findWord(word: String) = null
    override suspend fun insertWord(entry: com.example.data.local.DictionaryEntryEntity) {}
    override suspend fun insertWords(entries: List<com.example.data.local.DictionaryEntryEntity>) {}
}
